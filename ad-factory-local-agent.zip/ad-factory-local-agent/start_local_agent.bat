@echo off
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" scripts\start_local_agent.py %*
) else (
  py -3.12 scripts\start_local_agent.py %*
)
