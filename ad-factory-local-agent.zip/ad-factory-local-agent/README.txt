Ad Factory local agent
======================

Share this zip only. It already includes requirements-local-agent.txt
and the setup guides. Do not send extra files.

Unzip and leave these folders as they are:

  local_agent_runtime/
  scripts/
  dashboard/backend/
  docs/

Then open ONE guide and follow it:

  Windows:  docs/LOCAL_AGENT_WINDOWS.md
  Ubuntu:   docs/LOCAL_AGENT_UBUNTU.md
  macOS:    docs/LOCAL_AGENT_MAC.md

Install into a local .venv (do not pip install globally, do not activate):

  Windows:     py -3 -m venv .venv
               .venv\Scripts\python.exe -m pip install -r requirements-local-agent.txt
               .venv\Scripts\python.exe scripts\start_local_agent.py
               or double-click start_local_agent.bat

  Ubuntu/Mac:  python3 -m venv .venv
               .venv/bin/python -m pip install -r requirements-local-agent.txt
               .venv/bin/python scripts/start_local_agent.py
               or ./start_local_agent.sh

Do not run playwright install chromium. The agent uses installed Google Chrome.
