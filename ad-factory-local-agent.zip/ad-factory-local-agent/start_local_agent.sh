#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [ -x .venv/bin/python ]; then
  exec .venv/bin/python scripts/start_local_agent.py "$@"
fi
exec python3 scripts/start_local_agent.py "$@"
